import os
import json
import logging
import pandas as pd
import apache_beam as beam
from apache_beam import DoFn
from google.cloud import bigquery
from beam_nuggets.io import kafkaio
from google.cloud.exceptions import NotFound
from apache_beam.options.pipeline_options import PipelineOptions, SetupOptions, StandardOptions

#imprimir local que o pipeline esta rodando
# diretorio_atual = os.getcwd()
# usuario = os.getlogin()
# print("O diretório atual é:", diretorio_atual)
# print("O usuário atual é:", usuario)

# # define o modo de execução do pipeline
# if "opt" in diretorio_atual:
#     debug = True
#     print("Executando em modo de debug.")
# else:
#     debug = False
#     print("Executando em modo normal.")

# # variaveis de execução
# if debug:
#     # collection_read = 'user'
    

    
# else:
#     print("Não foi encontrado o diretório 'opt'. Encerrando o pipeline.")

def table_metadata(table, mapping_=False):
    #table_controller = "gs://streaming-v1/raw_controller.csv"
    table_controller = "gs://beegdata_engineer/metadados/raw_controller.csv"
    #project="focus-mechanic-321819"

    df = pd.read_csv(table_controller)


    df_filtered = df[df['target_table_name'] == table]

    field_mapping_str = df_filtered['field_mapping'].iloc[0]
    field_mapping = eval(field_mapping_str)
    field_mapping = [(t[0], 'integer') if t[1] == 'int' or t[1] == 'bigint' else t for t in field_mapping]
    mapping_str = ', '.join([f"{t[0]}:{t[1].upper()}" for t in field_mapping])
    mapp = [bigquery.SchemaField(t[0], t[1].upper()) for t in field_mapping]
    
    mapping_bq = [bigquery.SchemaField(field.name, field.field_type) for field in mapp] # Cria Schema simplificado do Big Query


   # mapping_bq = [bigquery.SchemaField(field.name, field.field_type) for field in mapp] # Cria Schema simplificado do Big Query
    #enginner_bucket = "gs://beegdata_engineer"
    #transient_bucket = df_filtered['transient_bucket'].values
    
    
    # raw_dataset = df_filtered['raw_dataset']
    #df_list = df_filtered.to_dict('records')

    # source_collection = df_json['source_table_name']
    # target_collection = df_json['target_table_name']

    #primary_key = df_filtered['primary_key'].values
    # temporay_key = primary_key.split(", ")
    
    partition_field = df_filtered['partition_field'].values

    #field_max_date = "cdc_commit_timestamp"

    if mapping_:
        return mapping_bq
        
        
    
    # print(target_collection)
    
    return mapping_bq, partition_field
  
class CheckJson(DoFn):

    def process(self, doc: dict):
        mapping = table_metadata(doc.get('table'), mapping_=True)
        
        columns_list = [x.split(':')[0].strip() for x in mapping.split(',')]

        print(columns_list)

        yield {k: v for k, v in doc.get('data').items() if k in columns_list}

class ToBQ(DoFn):

    def __init__(self, dataset, project_id):
        self.dataset = dataset.get()
        self.project = project_id.get()

    def process(self, doc: dict):
        mapping_bq, partition_field = table_metadata(doc.get('table'))

        client = bigquery.Client()

        table_ref = client.dataset(self.dataset, project=self.project).table(doc.get('table'))
        #raw_project = "focus-mechanic-321819"
        #raw_dataset= "beegdata_homolog"
        #target_collection = "is_help_read"
        
        #table_id2 = f"{raw_project}.{raw_dataset}.{target_collection}"
        table_id = f"{self.project}.{self.dataset}.{doc.get('table')}"
        #print("\nTablleeee idddddddddddeeeeeeeeeeeeeee", table_ref)
        

        try:
            table_check = client.get_table(table=table_ref)  # Make an API request.
            print("Table {} already exists.".format(table_id))

            if not table_check:
                try:
                    table = bigquery.Table(table_id, schema=mapping_bq)
                    table.range_partitioning = bigquery.RangePartitioning(
                        # To use integer range partitioning, select a top-level REQUIRED /
                        # NULLABLE column with INTEGER / INT64 data type.
                        field=partition_field,
                        range_=bigquery.PartitionRange(start=1, end=10000, interval=1),
                    )  
                    table = client.create_table(table)
                except:
                    # salvar_erro(*sys.exc_info())
                    print("erro aqui")
         
            
        except NotFound:
            print("Table {} isA not found.".format(table_id))

            try:
                print("Bomba picloe o table id é", table_id)
                print(partition_field, mapping_bq)
                table = bigquery.Table(table_id, schema=mapping_bq)
                print("\nPrintntttttttttttttttttttttt", table, "\nMappppppppppppppp",mapping_bq)
 
                table = client.create_table(table)
            except Exception as e:
                print("O erro foi aqui", e)
                #salvar_erro(*sys.exc_info())
                pass

        # try:
        #     table_exists = ,client.get_table(table=table_id)
        #     # if not table_ref:
        # except NotFound as error:
        '''  
        new_doc = doc.get('data')
        new_doc['database'] = doc.get('database')
                
        rows_to_insert = [new_doc]

        table = client.get_table(table=table_ref)

        client.insert_rows(
            table,
            rows_to_insert,
            
        )
        '''

        # insert_rows_json(
        #     , , row_ids=[None] * len(rows_to_insert)
        # )

        #yield

class RawOptions(PipelineOptions):

    @classmethod
    def _add_argparse_args(cls, parser):

        parser.add_value_provider_argument(
                                    '--dataset',
                                    required=True,
                                    type=str
        )
        
        parser.add_value_provider_argument(
                                    '--project_id',
                                    required=True,
                                    type=str
        )
        


def main():
    pipeline_options = PipelineOptions()
    pipeline_options.view_as(SetupOptions).save_main_session = True
    pipeline_options.view_as(StandardOptions).streaming = True
    pipe_options = pipeline_options.view_as(RawOptions)
    
    consumer_config = {"topic": "beev5",
                        "bootstrap_servers": "34.138.147.93:9093"}

    dataset = pipe_options.dataset
    project_id = pipe_options.project_id

    with beam.Pipeline(options=pipeline_options) as pipe:
        notifications = pipe | "Reading messages from Kafka" >> kafkaio.KafkaConsume(
            consumer_config=consumer_config,
            value_decoder=bytes.decode
        )
        
        try:
            to_json = (notifications   
                | "To Json" >> beam.Map(lambda doc: json.loads(doc[1]))
                # | "Check Json" >> beam.ParDo(CheckJson())
            )
        except Exception as e:
            mensagem_erro = "Ocorreu um erro na etapa pTransient do Pipeline pipe"
            # salvar_erro(*sys.exc_info())
        
        to_json | beam.ParDo(ToBQ(dataset, project_id))
			
if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    main()
