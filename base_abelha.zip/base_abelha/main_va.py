#importa as bibliotecas
import pandas as pd
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io import ReadFromParquet
from apache_beam.io.gcp.bigquery_tools import parse_table_schema_from_json
from apache_beam.io.gcp.internal.clients import bigquery
#from apache_beam.io.gcp.bigquery import DeleteFromTable
import pyarrow
import os
import json
import datetime
from datetime import datetime
from datetime import timedelta
from google.cloud import storage
from google.cloud import bigquery
import pytz
from pytz import timezone
import uuid
import avro.schema
from apache_beam.io import WriteToAvro
from apache_beam.io.avroio import ReadFromAvro
import sys
import glob
import traceback
import fastavro
from fastavro import parse_schema
import logging
#import json
#from google.cloud import storage
#import sys
#import traceback
#import itertools
#import time

#imprimir local que o pipeline esta rodando
diretorio_atual = os.getcwd()
usuario = os.getlogin()
print("O diretório atual é:", diretorio_atual)
print("O usuário atual é:", usuario)

# define o modo de execução do pipeline
if "opt" in diretorio_atual:
    debug = True
    print("Executando em modo de debug.")
else:
    debug = False
    print("Executando em modo normal.")

#variaveis de execução
if debug:
    collection_read = 'raw_user'
    table_controller = "gs://beegdata_engineer/metadados/trusted_controller.csv"

    df = pd.read_csv(table_controller)
    df_filtered = df[df['target_table_name'] == collection_read]
    field_mapping_str = df_filtered['field_mapping'].iloc[0]
    field_mapping = eval(field_mapping_str)
    field_mapping = [(t[0], 'integer') if t[1] == 'int' or t[1] == 'bigint' else t for t in field_mapping]
    mapping = ', '.join([f"{t[0]}:{t[1].upper()}" for t in field_mapping])
    mapp = [bigquery.SchemaField(t[0], t[1].upper()) for t in field_mapping]
    #mapping_simp = [f"bigquery.SchemaField(\"{field.name}\", \"{field.field_type}\")" for field in mapp] # Cria Schema simplificado do Big Query
    mapping_bq = [bigquery.SchemaField(field.name, field.field_type) for field in mapp] # Cria Schema simplificado do Big Query
    mapping_evol = [bigquery.SchemaField(t[0], t[1].upper()) for t in field_mapping]   # Cria Schema evoluido do Big Query
    enginner_bucket = "gs://beegdata_engineer"
    transient_bucket = df_filtered['transient_bucket'].iloc[0]
    raw_project="focus-mechanic-321819"
    raw_dataset = df_filtered['raw_dataset'].iloc[0]
    source_collection = df_filtered['source_table_name'].iloc[0]
    #target_collection = df_filtered['target_table_name'].iloc[0]
    target_collection = "raw_user"
    primary_key = df_filtered['primary_key'].iloc[0]
    temporay_key = primary_key.split(", ")
    partition_field = df_filtered['partition_field'].iloc[0]
    #primary_key = "coluna1"
    field_max_date = "cdc_commit_timestamp"
    database = "beedoo"

    
else:
    print("Não foi encontrado o diretório 'opt'. Encerrando o pipeline.")
print(raw_dataset,target_collection, mapping)


avro_schema = {
    "type": "record",
    "name": "upsert",
    "fields": [
        {"name": "table", "type": "string"},
        {"name": "id", "type": "string"},
        {"name": "database", "type": "string"},
        {"name": "transient_last_timestamp", "type": "string"},
        {"name": "ingestion_time", "type": "string"},
    ],
}

class PipeCustom(PipelineOptions):

    @classmethod
    def _add_argparse_args(cls, parser):
        parser.add_value_provider_argument(
            '--bucket_name',
            required=True
        )

beam_options = PipelineOptions()
pipe_options = beam_options.view_as(PipeCustom)
pipe_options.view_as(beam.options.pipeline_options.StandardOptions).streaming = True

def process_data(element):
    key, values = element
    data = {'key': key}
    if 'insert_data' in values:
        data.update(values['insert_data'][0])
    if 'update_data' in values:
        for update in values['update_data']:
            data.update(update)
    if 'delete_data' in values:
        return None
    return data
    
    
#############################################################################
'''
def filter_data(data, status):
    def filter_records(record):
        # Condição de filtro baseada nos dados da origem
        return record['status'] == status

    if status == 'insert':
        filtered_data = data | 'Filter Insert Records' >> beam.Filter(filter_records)
    elif status == 'update':
        filtered_data = data | 'Filter Update Records' >> beam.Filter(filter_records)
    elif status == 'deleted':
        filtered_data = data | 'Filter Deleted Records' >> beam.Filter(filter_records)
    else:
        raise ValueError('Invalid status')

    return filtered_data
    
# Lendo dados da origem
data = p | 'Read from file' >> ReadFromText('/path/to/input/file')

# Filtrando dados por status
insert_data = filter_data(data, 'insert')
update_data = filter_data(data, 'update')
deleted_data = filter_data(data, 'deleted')'''


#segunda ------------------------------------------------------------------------------
'''
def filter_data(data, status):
    def filter_records(record):
        # Condição de filtro baseada nos dados da origem
        return record['status'] == status

    return data | f'Filter {status.capitalize()} Records' >> beam.Filter(filter_records)

# Filtrando dados por status
insert_data = filter_data(data, 'insert')
update_data = filter_data(data, 'update')
deleted_data = filter_data(data, 'deleted')

# Instrução SQL para inserir/atualizar registros
upsert_sql = "INSERT INTO mytable (col1, col2, col3) VALUES (?, ?, ?) ON CONFLICT (col1) DO UPDATE SET col2=excluded.col2, col3=excluded.col3"

# Usando a transformação WriteToJdbc para inserir/atualizar registros no banco de dados
insert_data | 'Write Insert Records' >> WriteToJdbc(connection_config, upsert_sql, upsert=True)
update_data | 'Write Update Records' >> WriteToJdbc(connection_config, upsert_sql, upsert=True)

# Atualizando registros em um arquivo de texto
updated_data = update_data | 'Remove Status Column' >> beam.Map(lambda record: {key: value for key, value in record.items() if key != 'status'})
updated_data | 'Write Updated Records' >> beam.io.WriteToText('/path/to/output/file', append_trailing_newlines=True)

# Instrução SQL para excluir registros
delete_sql = "DELETE FROM mytable WHERE status = 'deleted'"

# Usando a transformação Delete para excluir registros no banco de dados
deleted_data | 'Delete Records' >> Delete(connection_config, delete_sql)'''
#---------------------------------------------------------------------------------------------------------------------------------------------
'''
def filter_records(record):
    # Condição de filtro baseada nos dados da origem
    return record['status'] == 'insert'

insert_data = data | 'Filter Insert Records' >> beam.Filter(filter_records)

# Instrução SQL para inserir registros
insert_sql = "INSERT INTO mytable (col1, col2, col3) VALUES (?, ?, ?)"

# Usando a transformação WriteToJdbc para inserir registros no banco de dados
insert_data | 'Write Insert Records' >> WriteToJdbc(connection_config, insert_sql)'''
#----------------------------------------------------------------------------
'''
def filter_records(record):
    # Condição de filtro baseada nos dados da origem
    return record['status'] == 'update'

update_data = data | 'Filter Update Records' >> beam.Filter(filter_records)

# Atualizando registros em um arquivo de texto
updated_data | 'Write Updated Records' >> WriteToText('/path/to/output/file', append_trailing_newlines=True)

'''

#----------------------------------------------------------------------------

def filter_records_delete(record):
    # Condição de filtro baseada nos dados da origem
    return record['username'] == 'deleted'

#filtered_data = data | 'Filter Records' >> beam.Filter(filter_records)

# Instrução SQL para excluir registros
#delete_sql = "DELETE FROM beegdata.homolog.raw_user WHERE username = 'deleted'"

# Usando a transformação Delete para excluir registros no banco de dados
#filtered_data | 'Delete Records' >> Delete(connection_config, delete_sql)


#terceiro             -----------------------------------------------------------------
'''
from apache_beam.io.gcp.bigquery_tools import parse_table_schema_from_json

# Define o esquema da tabela BigQuery
#table_schema_json = '{"fields":[{"name":"col1","type":"STRING"},{"name":"col2","type":"INTEGER"},{"name":"col3","type":"FLOAT"}]}'
#table_schema = parse_table_schema_from_json(table_schema_json)
'''
# Função para fazer upsert
def upsert_record(record):
    from google.cloud import bigquery

    # Configuração do cliente BigQuery
    client = bigquery.Client()
    table_id = pro
    table = client.get_table(table_id)

    # Faz a busca por chave primária (col1)
    query_job = client.query(f"SELECT id FROM `{table_id}` WHERE id='{record['id']}'")
    results = query_job.result()

    # Insere ou atualiza registros com base na chave primária
    if len(list(results)) > 0:
        # Atualiza registro existente
        print("\nVaidarcerto")
        '''
        update_statement = f"""
            UPDATE `{table_id}`
            SET col2={record['col2']}, col3={record['col3']}
            WHERE col1='{record['id']}'
        """
        '''
        #client.query(update_statement)
    else:
        # Insere novo registro
        rows_to_insert = [record]
        client.insert_rows(table, rows_to_insert)

    return record
'''
# Lendo dados da origem
data = p | 'Read from file' >> ReadFromText('/path/to/input/file')

# Transformando dados com a função upsert_record
upserted_data = data | 'Upsert Records' >> beam.Map(upsert_record)

# Escrevendo dados na tabela BigQuery
upserted_data | 'Write to BigQuery' >> WriteToBigQuery(
    table='my-project-id.my_dataset.my_table',
    schema=table_schema,
    write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE,
    create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)
'''
 # quarto --------------------------------------------------------------------------------------------------------------
'''
from apache_beam.io.gcp.bigquery_tools import parse_table_schema_from_json

# Define o esquema da tabela BigQuery
#table_schema_json = '{"fields":[{"name":"col1","type":"STRING"},{"name":"col2","type":"INTEGER"},{"name":"col3","type":"FLOAT"}]}'
schema
table_schema = parse_table_schema_from_json(table_schema_json)

# Função para fazer upsert
def upsert_record(record):
    from google.cloud import bigquery

    # Configuração do cliente BigQuery
    client = bigquery.Client()
    table_id = target_collection
    table = client.get_table(table_id)

    # Faz a busca por chave primária (col1)
    query_job = client.query(f"SELECT id, database FROM `{table_id}` WHERE col1='{record['id, database']}'")
    results = query_job.result()

    # Cria um dicionário com os valores a serem atualizados
    values_to_update = {'team_id': record['team_id'], 'col3': record['col3']}

    # Converte o dicionário em uma lista de strings contendo as colunas e seus respectivos valores atualizados
    set_strings = [f"{key}='{value}'" for key, value in values_to_update.items()]

    # Junta as strings em uma única string separada por vírgulas
    set_string = ", ".join(set_strings)
    if len(list(results)) > 0:
        # Atualiza registro existente
        update_statement = f"""
            UPDATE `{table_id}`
            SET {set_string}
            WHERE col1='{record['id, database']}'
        """
        client.query(update_statement)
    else:
        # Insere novo registro
        rows_to_insert = [record]
        client.insert_rows(table, rows_to_insert)

    return record

# Lendo dados da origem
data = p | 'Read from file' >> ReadFromText('/path/to/input/file')

# Filtrando dados por status
insert_data = data | 'Filter Insert Records' >> beam.Filter(lambda record: record['status'] == 'insert')
update_data = data | 'Filter Update Records' >> beam.Filter(lambda record: record['status'] == 'update')
deleted_data = data | 'Filter Deleted Records' >> beam.Filter(lambda record: record['status'] == 'deleted')

# Transformando dados com a função upsert_record
upserted_insert_data = insert_data | 'Upsert Insert Records' >> beam.Map(upsert_record)
upserted_update_data = update_data | 'Upsert Update Records' >> beam.Map(upsert_record)

# Escrevendo dados na tabela BigQuery
upserted_insert_data | 'Write Insert Records to BigQuery' >> WriteToBigQuery(
    table='my-project-id.my_dataset.my_table',
    schema=table_schema,
    write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE,
    create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

upserted_update_data | 'Write Update Records to BigQuery' >> WriteToBigQuery(
    table='my-project-id.my_dataset.my_table',
    schema=table_schema,
    write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
    create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

# Instrução SQL para excluir registros
delete_sql = "DELETE FROM `my-project-id.my_dataset.my_table` WHERE status = 'deleted'"

# Usando a transformação ExecuteQuery para excluir registros no BigQuery
upserted_data | 'Delete Records' >> ExecuteQuery(delete_sql)

'''




##########################################################################################
# Cria um cliente do BigQuery
client = bigquery.Client()

# Defina as informações da tabela que você deseja modificar.
table_id = f"{raw_project}.{raw_dataset}.{target_collection}"
query = 'SELECT * FROM beegdata_homolog.user'
delete_query = "DELETE FROM beegdata.homolog.raw_user WHERE username = 'deleted'"

from google.cloud import bigquery

# Define as informações da tabela que você deseja modificar.
filter_clause = 'username = "carolsenger"'

# Define a consulta DELETE.
#delete_query = f'DELETE FROM `{table_id}` WHERE {filter_clause}'

# Cria um cliente BigQuery e executa a consulta DELETE.
#client = bigquery.Client()
#query_job = client.query(delete_query)

def delete_rows(row):
    table_id = f"{raw_project}.{raw_dataset}.{target_collection}"
    # Define as informações da tabela que você deseja modificar.
    filter_clause = 'username = "edwar.vicente"'
    # Define a consulta DELETE.
    delete_query = f'DELETE FROM `{table_id}` WHERE {filter_clause}'
    client = bigquery.Client()
    query_job = client.query(delete_query)
    num_deleted_rows = query_job.num_dml_affected_rows
    return num_deleted_rows



# Função para fazer upsert
def upsert_record(record):
    # Configuração do cliente BigQuery
    table_id = f"{raw_project}.{raw_dataset}.{target_collection}"
    table = client.get_table(table_id)

    # Faz a busca por chave primária (col1)
    query_job = client.query(f"SELECT id FROM `{table_id}` WHERE id='{record['id']}'")
    results = query_job.result()

    # Insere ou atualiza registros com base na chave primária
    if len(list(results)) > 0:
        # Atualiza registro existente
        print("\nVaidarcerto")
        '''
        update_statement = f"""
            UPDATE `{table_id}`
            SET col2={record['col2']}, col3={record['col3']}
            WHERE col1='{record['id']}'
        """
        '''
        #client.query(update_statement)
    else:
        # Insere novo registro
        rows_to_insert = [record]
        client.insert_rows(table, rows_to_insert)

    return record
    

# Imprime o número de linhas deletadas.
#print(f'{query_job.num_dml_affected_rows} linhas deletadas da tabela {table_id}.')



print("\nTempraryyyy", temporay_key)
with beam.Pipeline(options=beam_options) as pipe:
         p_collection = (
             pipe
             | 'Ler do BigQuery' >> beam.io.ReadFromBigQuery(query=query, use_standard_sql=True)
             | beam.Filter(lambda team: team['team_id'] == 400)
             #| beam.Map(print)
         )
         # Aplica a transformação Map para deletar as linhas que correspondem ao filtro.
         
         deleted_rows_count = (
             p_collection
             | beam.Map(delete_rows)
             #| beam.CombineGlobally(sum)
         )
         # Imprime o número de linhas deletadas.
         #print(f'{deleted_rows_count} linhas deletadas da tabela {table_id}.')
 #client.delete_rows(table_ref, filter_=filter_clause)      
#delete_from_table = DeleteFromTable(raw_project, raw_dataset, target_collection, delete_query)
#result = pipeline | 'Delete Records' >> delete_from_table

         
         '''
         # Divida os dados em coleções baseadas na operação
         insert_data = p_collection | beam.Filter(lambda x: x['username'] in ['I', None])
         update_data = p_collection | beam.Filter(lambda x: x['username'] == 'U')
         delete_data = p_collection | beam.Filter(lambda x: x['username'] == 'adecco')
         
         # Use CoGroupByKey para combinar todas as coleções
         merged_data = ({'insert_data': insert_data, 'update_data': update_data, 'delete_data': delete_data} 
               | beam.CoGroupByKey())

         # Aplique a função de processamento aos dados combinados
         merged_data = merged_data | beam.Map(process_data)

         # Escreva os dados mesclados resultantes no destino
         merged_data | beam.io.WriteToBigQuery(
                      table=target_collection,dataset=raw_dataset
                    )'''


 

    

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    #main()
    
    
'''
         client = bigquery.Client()
         table_id = f"{raw_project}.{raw_dataset}.{target_collection}"
         table = bigquery.Table(table_id, schema=mapping_bq)
         table.range_partitioning = bigquery.RangePartitioning(
              # To use integer range partitioning, select a top-level REQUIRED /
              # NULLABLE column with INTEGER / INT64 data type.
              field=partition_field,
              range_=bigquery.PartitionRange(start=1, end=10000, interval=1),
         )   
         table = client.create_table(table)
                 
         pRaw = (
             p_collection |  "Desfazer chave transient" >> beam.Map(lambda x: x[1]['transient'])
                    |"WriteToBigQuery" >> beam.io.WriteToBigQuery(
                      table=target_collection,dataset=raw_dataset
                    )
                    # | beam.Map(print)
         )
         '''