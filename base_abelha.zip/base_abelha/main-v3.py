import json
import time
import pandas as pa
from kafka import KafkaProducer

def on_success(record):
    print('ENVIADO!')

def on_error(excp):
    print(excp, 'erro')
    raise Exception(excp)

df = pa.read_parquet('./is_help_read.parquet')

records = df.to_dict('records')

producer = KafkaProducer(retries=5, bootstrap_servers=['34.138.147.93:9093'])

for men in records:
    doc = {
        'database': 'fis',
        'table': 'is_help_read',
        'data': men
    }
    
    doc['data']['created_at'] = str(men['created_at'])
    doc['data']['cdc_commit_timestamp'] = str(men['cdc_commit_timestamp'])

    producer.send('beev5', json.dumps(doc).encode('utf-8')).add_callback(on_success).add_errback(on_error)
    producer.flush()
    break