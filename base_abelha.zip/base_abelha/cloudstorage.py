#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar 25 10:51:59 2023

@author: rodrigo
"""
import fsspec
import pandas as pd
from google.cloud import storage

# Especifique o nome do projeto GCS
project_name = "focus-mechanic-321819"
bucket_name = "beeai-prd-trusted-zone"

# Crie uma conexão com o GCS usando as credenciais padrão do Google Cloud SDK e o nome do projeto
client = storage.Client(project=project_name)

################ lista os bucket #########################
# Liste os buckets no GCS
buckets = list(client.list_buckets())

'''
# Imprima o nome de cada bucket
for bucket in buckets:
    print(bucket.name)'''
    

############### le os conujtos de dados #####################

directory = "gs://beeai-prd-trusted-zone/database/beeai_preprod/helpcategory/**/*"

fs = fsspec.filesystem("gs")
file_list = fs.glob(directory)

parquet_files = [file for file in file_list if file.endswith('.parquet')]

#print(parquet_files)
dfs = []
for file_path in parquet_files:
    with fs.open(file_path, "rb") as f:
        df = pd.read_parquet(f)
        dfs.append(df)

df_cloud = pd.concat(dfs)

# Filtrar o DataFrame onde a coluna "database" é igual a "beedoo"
#final_df = final_df.loc[final_df['database'] == 'beedoo']



print(df_cloud)


