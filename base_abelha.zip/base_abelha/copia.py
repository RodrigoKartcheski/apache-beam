#importa as bibliotecas
import pandas as pd
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io import ReadFromParquet
from apache_beam.io.gcp.bigquery_tools import parse_table_schema_from_json
from apache_beam.io.gcp.internal.clients import bigquery
#from apache_beam.io.gcp.bigquery import DeleteFromTable
import pyarrow
import os
import json
import re
import datetime
from datetime import datetime
from datetime import timedelta
from google.cloud import storage
from google.cloud import bigquery
import pytz
from pytz import timezone
import uuid
import avro.schema
from apache_beam.io import WriteToAvro
from apache_beam.io.avroio import ReadFromAvro
import sys
import glob
import traceback
import fastavro
from fastavro import parse_schema
import logging
#import json
#from google.cloud import storage
#import sys
#import traceback
#import itertools
#import time

#imprimir local que o pipeline esta rodando
diretorio_atual = os.getcwd()
usuario = os.getlogin()
print("O diretório atual é:", diretorio_atual)
print("O usuário atual é:", usuario)

# define o modo de execução do pipeline
if "opt" in diretorio_atual:
    debug = True
    print("Executando em modo de debug.")
else:
    debug = False
    print("Executando em modo normal.")

#variaveis de execução
if debug:
    collection_read = 'raw_user'
    table_controller = "gs://beegdata_engineer/metadados/trusted_controller.csv"

    df = pd.read_csv(table_controller)
    #df_filtered = df[df['target_table_name'] == collection_read]
    df_filtered = df
    field_mapping_str = "('cdc_commit_timestamp', 'timestamp'),('id', 'int'),('code', 'string'),('transact_id', 'string')"
    field_mapping = eval(field_mapping_str)
    field_mapping = [(t[0], 'integer') if t[1] == 'int' or t[1] == 'bigint' else t for t in field_mapping]
    mapping = [('cdc_commit_timestamp', 'timestamp'),('id', 'int'),('code', 'string'),('transact_id', 'string')]
    mapp = [bigquery.SchemaField(t[0], t[1].upper()) for t in field_mapping]
    #mapping_simp = [f"bigquery.SchemaField(\"{field.name}\", \"{field.field_type}\")" for field in mapp] # Cria Schema simplificado do Big Query
    mapping_bq = [bigquery.SchemaField(field.name, field.field_type) for field in mapp] # Cria Schema simplificado do Big Query
    mapping_evol = [bigquery.SchemaField(t[0], t[1].upper()) for t in field_mapping]   # Cria Schema evoluido do Big Query
    enginner_bucket = "gs://beegdata_engineer"
    transient_bucket = df_filtered['transient_bucket'].iloc[0]
    raw_project="focus-mechanic-321819"
    raw_dataset = df_filtered['raw_dataset'].iloc[0]
    source_collection = df_filtered['source_table_name'].iloc[0]
    #target_collection = df_filtered['target_table_name'].iloc[0]
    target_collection = "raw_user"
    primary_key = df_filtered['primary_key'].iloc[0]
    temporay_key = primary_key.split(", ")
    partition_field = df_filtered['partition_field'].iloc[0]
    #primary_key = "coluna1"
    field_max_date = "cdc_commit_timestamp"
    database = "beedoo"
    
    columns = mapping.split()[2:]
    mapping_dict = {}
    for col in columns:
        name, dtype = col.split(":")
        mapping_dict[name] = dtype.rstrip(',')

    
else:
    print("Não foi encontrado o diretório 'opt'. Encerrando o pipeline.")
print(raw_dataset,target_collection)


class PipeCustom(PipelineOptions):

    @classmethod
    def _add_argparse_args(cls, parser):
        parser.add_value_provider_argument(
            '--bucket_name',
            required=True
        )

beam_options = PipelineOptions()
pipe_options = beam_options.view_as(PipeCustom)
pipe_options.view_as(beam.options.pipeline_options.StandardOptions).streaming = False


client = bigquery.Client()
table_id = f"{raw_project}.{raw_dataset}.{target_collection}"
def delete_rows(row):
    # Define as informações da tabela que você deseja modificar.
    filter_clause = 'username = "edwar.vicente"'
    # Define a consulta DELETE.
    delete_query = f'DELETE FROM `{table_id}` WHERE {filter_clause}'
    client = bigquery.Client()
    query_job = client.query(delete_query)
    num_deleted_rows = query_job.num_dml_affected_rows
    return num_deleted_rows

primary_key = ['id','team_id']

def upsert_record(record):
    table = bigquery.Table(table_id, schema=mapping_bq)
    
    pk_values = [int(record.get(pk)) if isinstance(record.get(pk), int) else f"'{record.get(pk)}'" for pk in primary_key]
    pk_string = " AND ".join([f"{pk}={pk_values[i]}" for i, pk in enumerate(primary_key)])
    
    # Separando a string pelos separadores ', ' e ':'
    elements = mapping.split(", ")
    elements = [element.split(":") for element in elements]
    # Criando o dicionário de colunas
    columns = {element[0]: element[0] for element in elements}

    columns = {"id": "id", "team_id": "team_id", "agentid":"agentid","firstaccess":"firstaccess","cdc_commit_timestamp":"cdc_commit_timestamp","database": "database"}
    update_columns = [f"{column}={record[value]!r}" if value in record and record[value] is not None else f"{column}=NULL" for column, value in columns.items()]
    #update_columns = [f"{column}={record[value]!r}" for column, value in columns.items()]
    update_string = ", ".join(update_columns)   
    #update_statement = f"UPDATE {table_id} SET {update_string} WHERE {pk_string}"
    #update_statement = f"UPDATE `{table_id}` SET id=115609, team_id=400, database='beedoo' WHERE {pk_string}"
    update_statement = f"UPDATE `{table_id}` SET {update_string} WHERE {pk_string}"

    
    query_job = client.query(f"SELECT {', '.join(primary_key)} FROM `{table_id}` WHERE {pk_string}")
    results = query_job.result()
    
    if len(list(results)) > 0:
        # Atualiza registro existente
        print('\nUUUUUUUUUUUUupdate_statement',update_statement)
        client.query(update_statement)
   
    else:
        # Insere novo registro
        rows_to_insert = [record]
        client.insert_rows(table, rows_to_insert)
    
    return record

columns_list  = [x.split(':')[0].strip() for x in mapping.split(',')]
def select_columns(element, columns):
    return {k: v for k, v in element.items() if k in columns}

def map_column_types(row, mapping_dict):
    for column, data_type in mapping_dict.items():
        if data_type == "STRING":
            row[column] = str(row[column])
        elif data_type == "INTEGER":
            if row[column] is not None:
                row[column] = int(row[column])
        elif data_type == "FLOAT":
            if row[column] is not None:
                row[column] = float(row[column])
        elif data_type == "BOOLEAN":
            row[column] = bool(row[column])
        elif data_type == "DATETIME":
            if row[column] is not None and not isinstance(row[column], datetime):
                row[column] = datetime.fromtimestamp(row[column] / 1000.0)
            else:
                pass # ignore column if already a datetime object
        elif data_type == "DATE":
            if row[column] is not None and not isinstance(row[column], date):
                row[column] = datetime.fromtimestamp(row[column] / 1000.0).date()
            else:
                pass # ignore column if already a date object
        elif data_type == "TIMESTAMP":
            if row[column] is not None and not isinstance(row[column], datetime):
                # ignore column if it is of type TIMESTAMP
                pass
        else:
            print(f"Data type {data_type} not supported!")
    return row


# Define a lista de colunas que deseja converter para inteiro
cols_to_convert = ['agentid', 'template_id']
# Define uma função que converte as colunas listadas para inteiro e atualiza a linha original
def convert_cols_to_int(row, cols_to_convert):
    for col in cols_to_convert:
        if row[col] is not None:
            row[col] = int(row[col])
        else:
            row[col] = None
    return row

cols_to_timestamp = ['firstaccess','cdc_commit_timestamp'] #cdc_commit_timestamp
def convert_cols_to_timestamp(row, cols_to_timestamp):
    for col in cols_to_timestamp:
        if row[col] is not None:
            try:
                row[col] = datetime.strptime(row[col], '%Y-%m-%d %H:%M:%S.%f')
                #converte de volta para string
                row[col] = row[col].strftime('%Y-%m-%d %H:%M:%S.%f')
            except:
                pass
            try:
                dt_str = row[col].isoformat().replace("T", " ")
                dt_str = re.sub(r'\.\d+', '', dt_str)
                dt_str = re.sub(r'\+\d+:\d+', '', dt_str)
                dt_str += '.000000'
                row[col] = dt_str
            except:
                pass
        else:
            row[col] = None
    return row

columns = mapping.split()[2:]
mapping_dict = {}
for col in columns:
    name, dtype = col.split(":")
    mapping_dict[name] = dtype.rstrip(',')
print(mapping_dict)

def print_column_types(input_table):
    # Parse the schema of the input table
    table_schema = bigquery_tools.parse_table_schema_from_json(input_table.schema)

    # Print the name and data type of each column
    for field in table_schema.fields:
        print(f"{field.name}: {field.field_type}")
        
# Imprime o número de linhas deletadas.
#print(f'{query_job.num_dml_affected_rows} linhas deletadas da tabela {table_id}.')
from datetime import datetime, timedelta
#query = 'SELECT * FROM beegdata_homolog.user'

def filter_raw_user(raw_project, raw_dataset, source_collection, minutes_before=120, minutes_after=35):
    end_time = datetime.now()
    start_time = end_time - timedelta(minutes=minutes_before)
    end_time = end_time - timedelta(minutes=minutes_after)
    start_time_str = start_time.strftime('%Y-%m-%d %H:%M:%S')
    end_time_str = end_time.strftime('%Y-%m-%d %H:%M:%S')
    query = f"""
        SELECT *
        FROM `{raw_project}.{raw_dataset}.{source_collection}`
        WHERE 1 = 1
        AND dateload >= TIMESTAMP('{start_time_str}')
        AND dateload < TIMESTAMP('{end_time_str}')
    """
    return query

print("\nTempraryyyy", primary_key)
with beam.Pipeline(options=beam_options) as pipe:
         p_collection = (
             pipe
             | 'Ler do BigQuery' >> beam.io.ReadFromBigQuery(query=filter_raw_user(raw_project, raw_dataset, source_collection), use_standard_sql=True)
             | beam.Map(lambda row: row.update({'Op': ''}) or row)
             | "selecionar colunas" >> beam.Map(select_columns, columns_list)
             | 'Mapear tipos de colunas' >> beam.Map(lambda row: map_column_types(row, mapping_dict))
             | beam.Map(lambda row: convert_cols_to_int(row, cols_to_convert))
             | beam.Map(lambda row: convert_cols_to_timestamp(row, cols_to_timestamp))
         )
         '''
         # Aplica a transformação Map para deletar as linhas que correspondem ao filtro.
         table = bigquery.Table(table_id, schema=mapping_bq)
         table.range_partitioning = bigquery.RangePartitioning(
              # To use integer range partitioning, select a top-level REQUIRED /
              # NULLABLE column with INTEGER / INT64 data type.
              field=partition_field,
              range_=bigquery.PartitionRange(start=1, end=10000, interval=1),
         )   
         table = client.create_table(table)
        '''
         
         load_to_bq = (
             p_collection
             #| beam.Map(delete_rows)
             | beam.Map(upsert_record)
             #| beam.CombineGlobally(sum)
         )
   

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    #main()
    
    
    
    