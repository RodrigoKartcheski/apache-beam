
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
import pandas as pd
#import pandas as pd
#import ast
import logging

table_controller = "gs://beeai-prd-refined-zone/raw_controller.csv"
#bucket_name = "gs://beeai-prd-refined-zone"
bucket_name = "gs://beeai-prd-transient-zone/prod/database/beedoo"
input_path = f'{bucket_name}/testing/*.parquet'
collection_read = 'testing'
output_table = "project focus-mechanic-321819.beegdata_homolog"


df = pd.read_csv(table_controller)
df_filtered = df[df['source_table_name'] == collection_read]
field_mapping_str = df_filtered['field_mapping'].iloc[0]
field_mapping = eval(field_mapping_str)
field_mapping = [(t[0], 'integer') if t[1] == 'int' or t[1] == 'bigint' else t for t in field_mapping]
mapping = ', '.join([f"{t[0]}:{t[1].upper()}" for t in field_mapping])

print(mapping)

'''
input_bucket = "gs://beeai-prd-transient-zone"
output_table = "project focus-mechanic-321819.beegdata_homolog.user"

schema = "field_1:STRING, field_2:INTEGER, field_3:FLOAT"

options = PipelineOptions()
options.view_as(beam.options.pipeline_options.GoogleCloudOptions).streaming = True
options.view_as(beam.options.pipeline_options.StandardOptions).runner = 'DirectRunner'
options.view_as(beam.options.pipeline_options.StandardOptions).streaming = True

with beam.Pipeline(options=options) as p:
    (p | "ReadFromGCS" >> beam.io.ReadFromText(input_bucket, watch_interval_seconds=10)
       | "TransformData" >> beam.Map(lambda x: tuple(x.split(',')))
       | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
           output_table,
           schema=schema,
           create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
           write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND)
    )

'''
class PipeCustom(PipelineOptions):

    @classmethod
    def _add_argparse_args(cls, parser):
        parser.add_value_provider_argument(
            '--bucket_name',
            required=True
        )

beam_options = PipelineOptions()
pipe_options = beam_options.view_as(PipeCustom)
pipe_options.view_as(beam.options.pipeline_options.StandardOptions).streaming = True




bucket_name = pipe_options.bucket_name
raw_table = "user"

def parquet_to_dict(row):
    # Converte o registro do parquet em um dicionário
    return dict(row)
import itertools

import time

schema= "id:INTEGER, team_id:INTEGER"
#schema= "cdc_commit_timestamp:STRING, id:INTEGER, team_id:INTEGER, usertype_id:INTEGER, userstatus_id:INTEGER, useravatar_id:INTEGER, template_id:INTEGER, agentid:INTEGER, externalid:STRING, username:STRING, name:STRING, lastname:STRING, email:STRING, place:STRING, cell:STRING, position:STRING, phone:STRING, branch:STRING, cellphone:STRING, description:STRING, password:STRING, img:STRING, newsletter:INTEGER, score:INTEGER, level:STRING, touruser:TIMESTAMP, touradm:TIMESTAMP, entrytime:STRING, exittime:STRING, acceptprivacy:INTEGER, required_mood:INTEGER, blockdm:INTEGER, blockmobile:INTEGER, blockscale:INTEGER, changepassword:INTEGER, status:INTEGER, uac_id:INTEGER, cpf:STRING, leader:INTEGER, changeusername:INTEGER, mention:INTEGER, nid:INTEGER, created:TIMESTAMP, created_by:INTEGER, firstaccess:TIMESTAMP, lastaccess:TIMESTAMP, idiom_id:INTEGER, fuso_name:STRING, mood_id:INTEGER, login:STRING, acceptprivacy_datetime:TIMESTAMP, acceptprivacy_from:STRING, acceptprivacystore:INTEGER, useredited_by:INTEGER, useredited_at:TIMESTAMP, transact_id:STRING, dateload:TIMESTAMP"

# Definir duração das janelas (em segundos)
window_size = 10
             
with beam.Pipeline(options=beam_options) as pipe:
     pDestino = (
        pipe | "Importar dados" >> beam.io.ReadFromParquet("gs://beeai-prd-transient-zone/prod/database/beedoo/testing/*.parquet")
             #| "Selecionar colunas" >> beam.Map(lambda x: {'id': x['id'], 'team_id': x['team_id']})
             #| "Filtrar linhas" >> beam.Filter(lambda x: x["team_id"] < 480)
            #| beam.Map(print)
             | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                 table=collection_read,dataset='beegdata_homolog',
                 schema=mapping,
                 create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
                 write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
                 )
     )
                     


    

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    #main()
    
    
'''
with beam.Pipeline(options=beam_options) as pipe:
     pDestino = (
        pipe | "Importar dados" >> beam.io.ReadFromParquet("gs://beeai-prd-transient-zone/prod/database/beedoo/user/*.parquet")
             | "Selecionar colunas" >> beam.Map(lambda x: {'id': x['id'], 'team_id': x['team_id']})
             | "Filtrar linhas" >> beam.Filter(lambda x: x["team_id"] < 480)
            #| beam.Map(print)
             | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                 table='user_one',dataset='beegdata_homolog',
                 schema=schema,
                 create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
                 write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                 schema_update_options=['ALLOW_FIELD_ADDITION'])
                 )'''
 
 
 